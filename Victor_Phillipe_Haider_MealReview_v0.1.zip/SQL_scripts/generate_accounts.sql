use `mealreview` ;

-- Insert administrators --
INSERT INTO `Account` (`Username`,`AccountType`,`Email`,`Password`)
    VALUES
    ("Victor Fernandes", 1, "victorvalenca@gmail.com", "vicpass"),
    ("Phillipe Pelchat", 1, "phillipepelchat@gmail.com", "philpass"),
    ("Haider Ali", 1, "haider.hotmail@gmail.com", "haipass");
    
-- This is just junk data for demo purposes. 
INSERT INTO `Account` (`Username`,`AccountType`,`Email`,`Password`)
	VALUES 
    ("mi eleifend",0,"fermentum.risus.at@interdum.co.uk","XXV99NJI9AI"),
    ("nec orci.",0,"sit@enim.org","XFD59GBO9GK"),
    ("quam vel",0,"porttitor.interdum.Sed@orciDonec.co.uk","XVL61MCG8HL"),
    ("velit. Aliquam",0,"Ut.semper@in.co.uk","YKM85UYK9QB"),
    ("massa. Suspendisse",0,"erat.eget@pedePraesenteu.edu","UZO16QJI4FE"),
    ("In condimentum.",0,"ut@Suspendisseac.co.uk","AGD91WMI0QM"),
    ("primis in",0,"sapien.gravida.non@sitametconsectetuer.edu","WFQ97TVH4HV");
